var before = "p";
var after = ".png";
var cmax = 100;
var wait = 10;